#include "PlayingMode.hpp"
BOOST_MSM_BACK_GENERATE_PROCESS_EVENT(PlayingMode)
