#include <iostream>
#include "Open.hpp"

void Open::close_drawer(open_close const&)   
{ 
    std::cout << "Open::close_drawer\n"; 
}
