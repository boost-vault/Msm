#include <iostream>
#include "Empty.hpp"

void Empty::open_drawer(open_close const&)    
{ 
    std::cout << "Empty::open_drawer\n"; 
}
